package com.xyz.changefeed.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChangeFeedApplicationTests {

	@Test
	void contextLoads() {
	}

}
